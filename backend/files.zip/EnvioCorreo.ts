// US40: contratos del envío de correo de emergencia. El servicio depende de estas interfaces,
// no de SMTP, de la base de datos ni del motor de alertas, así que cada pieza se puede cambiar o simular.

/** Lo mínimo de una alerta que necesita el correo. Coincide con el tipo Alerta del frontend. */
export interface DatosAlertaCorreo {
  id: number;
  entidad: string;
  tipo: "TASA" | "RIESGO";
  tasaAnterior: string;
  tasaNueva: string;
  /** Variación porcentual de la tasa, por ejemplo "-15.56%". */
  variacionPct: string;
  /** Calificación de la SBS antes y después del cambio; null si la entidad no tiene datos. */
  calificacionAnterior: string | null;
  calificacion: string | null;
}

/** Correo ya armado, listo para enviar. */
export interface ContenidoCorreo {
  asunto: string;
  html: string;
  texto: string;
}

/** Envía un correo. Devuelve false si el proveedor no lo aceptó; puede lanzar si el servicio falla. */
export interface ProveedorCorreo {
  enviar(para: string, contenido: ContenidoCorreo): Promise<boolean>;
}

/** Datos de un usuario que necesita el envío. SqliteUserRepository ya lo cumple. */
export interface BuscadorUsuarios {
  findById(id: number): { email: string } | null;
}

/** Busca una alerta por su id. Lo implementará el módulo de alertas (US36/US38). */
export interface BuscadorAlertas {
  buscarPorId(id: number): DatosAlertaCorreo | null;
}

/** Una vez por intento de envío; sirve para auditar qué pasó con cada notificación. */
export interface IntentoEnvio {
  notificacionId: number;
  numero: number;
  resultado: "OK" | "ERROR";
  /** Mensaje del fallo, sin direcciones de correo; null si salió bien. */
  error: string | null;
  momento: Date;
}

export interface RegistroEnvios {
  registrarIntento(intento: IntentoEnvio): void;
  /** Se llama una sola vez cuando ya no se va a reintentar (se agotaron los intentos o no tenía sentido reintentar). */
  registrarAgotado(notificacionId: number, error: string): void;
}

/** Espera un tiempo. Las pruebas usan una versión que no espera de verdad. */
export interface Temporizador {
  esperar(ms: number): Promise<void>;
}
