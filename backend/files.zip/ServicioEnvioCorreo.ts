import type { ColaNotificaciones, NotificacionPendiente } from "../domain/ColaNotificaciones";
import type {
  BuscadorAlertas,
  BuscadorUsuarios,
  ContenidoCorreo,
  ProveedorCorreo,
  RegistroEnvios,
  Temporizador,
} from "../domain/EnvioCorreo";
import { PlantillaCorreoAlerta } from "./PlantillaCorreoAlerta";
import { PoliticaReintentos } from "./PoliticaReintentos";

export interface DependenciasEnvio {
  cola: ColaNotificaciones;
  usuarios: BuscadorUsuarios;
  alertas: BuscadorAlertas;
  proveedor: ProveedorCorreo;
  registro: RegistroEnvios;
  temporizador: Temporizador;
}

export interface OpcionesEnvio {
  plantilla?: PlantillaCorreoAlerta;
  politica?: PoliticaReintentos;
  /** Dirección del frontend, para el enlace al detalle de la alerta (US36). */
  frontendUrl?: string;
  ahora?: () => Date;
}

export interface ResultadoEnvio {
  enviado: boolean;
  /** Intentos realizados (0 si ni siquiera se pudo preparar el correo). */
  intentos: number;
}

/** Los mensajes de error no deben guardar direcciones de correo en el registro. */
function describirError(error: unknown): string {
  const mensaje = error instanceof Error ? error.message : String(error);
  return mensaje.replace(/[^\s@<>"']+@[^\s@<>"']+/g, "[correo]").slice(0, 200);
}

/**
 * TS-125: toma una notificación de la cola, arma el correo y lo envía.
 * Si falla, espera y reintenta (espera exponencial) hasta agotar los intentos. Cada intento
 * queda registrado y, si todos fallan, la notificación se marca como FALLIDA (US40, escenario 2).
 */
export class ServicioEnvioCorreo {
  private readonly plantilla: PlantillaCorreoAlerta;
  private readonly politica: PoliticaReintentos;
  private readonly frontendUrl: string;
  private readonly ahora: () => Date;

  constructor(
    private readonly dependencias: DependenciasEnvio,
    opciones: OpcionesEnvio = {},
  ) {
    this.plantilla = opciones.plantilla ?? new PlantillaCorreoAlerta();
    this.politica = opciones.politica ?? new PoliticaReintentos();
    this.frontendUrl = opciones.frontendUrl ?? process.env.FRONTEND_URL ?? "http://localhost:5173";
    this.ahora = opciones.ahora ?? (() => new Date());
  }

  /** Procesa la siguiente notificación de la cola; devuelve null si no hay ninguna. */
  async procesarSiguiente(): Promise<ResultadoEnvio | null> {
    const notificacion = this.dependencias.cola.siguiente();
    return notificacion === null ? null : this.procesar(notificacion);
  }

  async procesar(notificacion: NotificacionPendiente): Promise<ResultadoEnvio> {
    const { cola, usuarios, alertas, registro, temporizador } = this.dependencias;

    // Si faltan datos no tiene sentido reintentar: no es un fallo pasajero del servicio de correo.
    const usuario = usuarios.findById(notificacion.usuarioId);
    if (usuario === null) return this.fallarSinReintento(notificacion, "El usuario de la notificación no existe.");
    const alerta = alertas.buscarPorId(notificacion.alertaId);
    if (alerta === null) return this.fallarSinReintento(notificacion, "La alerta de la notificación no existe.");

    const contenido = this.plantilla.construir(alerta, this.enlaceA(alerta.id));

    let ultimoError = "";
    for (let intento = 1; intento <= this.politica.maxIntentos; intento++) {
      const error = await this.intentarEnviar(usuario.email, contenido);
      registro.registrarIntento({
        notificacionId: notificacion.id,
        numero: intento,
        resultado: error === null ? "OK" : "ERROR",
        error,
        momento: this.ahora(),
      });

      if (error === null) {
        cola.marcarEnviada(notificacion.id);
        return { enviado: true, intentos: intento };
      }

      ultimoError = error;
      // No se espera después del último intento: ya no habrá otro.
      if (intento < this.politica.maxIntentos) {
        await temporizador.esperar(this.politica.retrasoTras(intento));
      }
    }

    registro.registrarAgotado(notificacion.id, ultimoError);
    cola.marcarFallida(notificacion.id);
    return { enviado: false, intentos: this.politica.maxIntentos };
  }

  /** null si el correo salió bien; si no, el motivo del fallo. */
  private async intentarEnviar(para: string, contenido: ContenidoCorreo): Promise<string | null> {
    try {
      const aceptado = await this.dependencias.proveedor.enviar(para, contenido);
      return aceptado ? null : "El proveedor de correo no aceptó el mensaje.";
    } catch (error: unknown) {
      return describirError(error);
    }
  }

  private fallarSinReintento(notificacion: NotificacionPendiente, motivo: string): ResultadoEnvio {
    this.dependencias.registro.registrarAgotado(notificacion.id, motivo);
    this.dependencias.cola.marcarFallida(notificacion.id);
    return { enviado: false, intentos: 0 };
  }

  /** Enlace que abre la plataforma con el detalle de esa alerta (lo entiende useAlertas en el frontend). */
  private enlaceA(alertaId: number): string {
    const url = new URL("/", this.frontendUrl);
    url.searchParams.set("alerta", String(alertaId));
    return url.toString();
  }
}
