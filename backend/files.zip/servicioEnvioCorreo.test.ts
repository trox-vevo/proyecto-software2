import { describe, expect, it } from "vitest";
import { PoliticaReintentos } from "../../src/alertas/application/PoliticaReintentos";
import { ServicioEnvioCorreo } from "../../src/alertas/application/ServicioEnvioCorreo";
import type { ColaNotificaciones, NotificacionPendiente } from "../../src/alertas/domain/ColaNotificaciones";
import type {
  BuscadorAlertas,
  BuscadorUsuarios,
  ContenidoCorreo,
  DatosAlertaCorreo,
  IntentoEnvio,
  ProveedorCorreo,
  RegistroEnvios,
  Temporizador,
} from "../../src/alertas/domain/EnvioCorreo";

// Piezas falsas: ningún correo sale de verdad y las pruebas no esperan tiempo real.

const ALERTA: DatosAlertaCorreo = {
  id: 5,
  entidad: "Banco Andino Demo",
  tipo: "TASA",
  tasaAnterior: "4.50%",
  tasaNueva: "3.80%",
  variacionPct: "-15.56%",
  calificacionAnterior: "A-",
  calificacion: "A-",
};

const NOTIFICACION: NotificacionPendiente = { id: 12, usuarioId: 7, alertaId: 5, estado: "PENDIENTE" };

class ProveedorFalso implements ProveedorCorreo {
  llamadas: Array<{ para: string; contenido: ContenidoCorreo }> = [];

  /** Los primeros `fallos` envíos fallan: lanzando un error o, en modo "rechazo", devolviendo false. */
  constructor(
    private readonly fallos: number,
    private readonly modo: "excepcion" | "rechazo" = "excepcion",
  ) {}

  async enviar(para: string, contenido: ContenidoCorreo): Promise<boolean> {
    this.llamadas.push({ para, contenido });
    if (this.llamadas.length <= this.fallos) {
      if (this.modo === "rechazo") return false;
      throw new Error("fallo simulado de SMTP para persona@correo.com");
    }
    return true;
  }
}

class RegistroEnMemoria implements RegistroEnvios {
  intentos: IntentoEnvio[] = [];
  agotados: Array<{ notificacionId: number; error: string }> = [];

  registrarIntento(intento: IntentoEnvio): void {
    this.intentos.push(intento);
  }

  registrarAgotado(notificacionId: number, error: string): void {
    this.agotados.push({ notificacionId, error });
  }
}

class ColaEnMemoria implements ColaNotificaciones {
  enviadas: number[] = [];
  fallidas: number[] = [];

  constructor(private pendientes: NotificacionPendiente[] = []) {}

  siguiente(): NotificacionPendiente | null {
    return this.pendientes.shift() ?? null;
  }

  marcarEnviada(id: number): void {
    this.enviadas.push(id);
  }

  marcarFallida(id: number): void {
    this.fallidas.push(id);
  }
}

class TemporizadorFalso implements Temporizador {
  esperas: number[] = [];

  async esperar(ms: number): Promise<void> {
    this.esperas.push(ms);
  }
}

function crear(opciones: { fallos?: number; modo?: "excepcion" | "rechazo"; usuarioExiste?: boolean; alertaExiste?: boolean } = {}) {
  const proveedor = new ProveedorFalso(opciones.fallos ?? 0, opciones.modo);
  const registro = new RegistroEnMemoria();
  const cola = new ColaEnMemoria([NOTIFICACION]);
  const temporizador = new TemporizadorFalso();
  const usuarios: BuscadorUsuarios = {
    findById: (id) => (opciones.usuarioExiste === false || id !== 7 ? null : { email: "ana@ejemplo.com" }),
  };
  const alertas: BuscadorAlertas = {
    buscarPorId: (id) => (opciones.alertaExiste === false || id !== 5 ? null : ALERTA),
  };
  const servicio = new ServicioEnvioCorreo(
    { cola, usuarios, alertas, proveedor, registro, temporizador },
    { frontendUrl: "https://yupay.test" },
  );
  return { servicio, proveedor, registro, cola, temporizador };
}

describe("Servicio de envío de correo con reintentos (US40, TS-125 y TS-126)", () => {
  it("escenario 1: envía el correo al primer intento, lo registra y marca la notificación como enviada", async () => {
    const { servicio, proveedor, registro, cola, temporizador } = crear();

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: true, intentos: 1 });
    expect(proveedor.llamadas).toHaveLength(1);
    expect(proveedor.llamadas[0].para).toBe("ana@ejemplo.com");
    expect(proveedor.llamadas[0].contenido.asunto).toContain("Banco Andino Demo");
    expect(proveedor.llamadas[0].contenido.texto).toContain("https://yupay.test/?alerta=5");
    expect(registro.intentos.map((i) => i.resultado)).toEqual(["OK"]);
    expect(registro.agotados).toHaveLength(0);
    expect(cola.enviadas).toEqual([12]);
    expect(temporizador.esperas).toEqual([]);
  });

  it("escenario 2: si falla dos veces y luego funciona, reintenta con espera exponencial y lo envía", async () => {
    const { servicio, proveedor, registro, cola, temporizador } = crear({ fallos: 2 });

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: true, intentos: 3 });
    expect(proveedor.llamadas).toHaveLength(3);
    expect(temporizador.esperas).toEqual([1000, 2000]);
    expect(registro.intentos.map((i) => [i.numero, i.resultado])).toEqual([
      [1, "ERROR"],
      [2, "ERROR"],
      [3, "OK"],
    ]);
    expect(registro.agotados).toHaveLength(0);
    expect(cola.enviadas).toEqual([12]);
  });

  it("escenario 2: si los 3 intentos fallan, registra el error final y marca la notificación como fallida", async () => {
    const { servicio, proveedor, registro, cola, temporizador } = crear({ fallos: Infinity });

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: false, intentos: 3 });
    expect(proveedor.llamadas).toHaveLength(3);
    // No se espera después del último intento
    expect(temporizador.esperas).toEqual([1000, 2000]);
    expect(registro.intentos.map((i) => i.resultado)).toEqual(["ERROR", "ERROR", "ERROR"]);
    expect(registro.agotados).toHaveLength(1);
    expect(registro.agotados[0].notificacionId).toBe(12);
    expect(cola.fallidas).toEqual([12]);
    expect(cola.enviadas).toEqual([]);
  });

  it("que el proveedor rechace el correo (devuelva false) también cuenta como fallo", async () => {
    const { servicio, registro } = crear({ fallos: 1, modo: "rechazo" });

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: true, intentos: 2 });
    expect(registro.intentos[0]).toMatchObject({ numero: 1, resultado: "ERROR" });
    expect(registro.intentos[0].error).toContain("no aceptó");
  });

  it("el registro no guarda direcciones de correo, ni siquiera dentro del mensaje de error", async () => {
    const { servicio, registro } = crear({ fallos: Infinity });

    await servicio.procesar(NOTIFICACION);

    const texto = JSON.stringify([registro.intentos, registro.agotados]);
    expect(texto).not.toContain("persona@correo.com");
    expect(texto).not.toContain("ana@ejemplo.com");
    expect(texto).toContain("[correo]");
  });

  it("si el usuario no existe no envía nada ni reintenta: registra el motivo y marca la notificación como fallida", async () => {
    const { servicio, proveedor, registro, cola, temporizador } = crear({ usuarioExiste: false });

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: false, intentos: 0 });
    expect(proveedor.llamadas).toHaveLength(0);
    expect(temporizador.esperas).toEqual([]);
    expect(registro.agotados).toHaveLength(1);
    expect(cola.fallidas).toEqual([12]);
  });

  it("si la alerta no existe tampoco envía nada", async () => {
    const { servicio, proveedor, cola } = crear({ alertaExiste: false });

    const resultado = await servicio.procesar(NOTIFICACION);

    expect(resultado).toEqual({ enviado: false, intentos: 0 });
    expect(proveedor.llamadas).toHaveLength(0);
    expect(cola.fallidas).toEqual([12]);
  });

  it("procesarSiguiente toma la notificación de la cola y devuelve null cuando no queda ninguna", async () => {
    const { servicio, cola } = crear();

    expect(await servicio.procesarSiguiente()).toEqual({ enviado: true, intentos: 1 });
    expect(cola.enviadas).toEqual([12]);
    expect(await servicio.procesarSiguiente()).toBeNull();
  });
});

describe("Política de reintentos", () => {
  it("la espera se duplica en cada intento", () => {
    const politica = new PoliticaReintentos();

    expect([1, 2, 3].map((intento) => politica.retrasoTras(intento))).toEqual([1000, 2000, 4000]);
  });

  it("por defecto son 3 intentos en total", () => {
    expect(new PoliticaReintentos().maxIntentos).toBe(3);
  });

  it("rechaza valores inválidos", () => {
    expect(() => new PoliticaReintentos(0)).toThrow(RangeError);
    expect(() => new PoliticaReintentos(2.5)).toThrow(RangeError);
    expect(() => new PoliticaReintentos(3, -1)).toThrow(RangeError);
  });
});
